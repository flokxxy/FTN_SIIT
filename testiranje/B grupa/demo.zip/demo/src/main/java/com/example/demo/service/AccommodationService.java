package com.example.demo.service;

import com.example.demo.exception.NotFoundException;
import com.example.demo.model.Accommodation;
import com.example.demo.repository.AccommodationRepository;

public class AccommodationService {

    private final AccommodationRepository repository;

    public AccommodationService(AccommodationRepository repository) {
        this.repository = repository;
    }

    public void save(Accommodation accommodation) {
        repository.save(accommodation);
    }

    public Accommodation getByReservationId(long reservationId) {
        return repository.findByReservationId(reservationId)
                .orElseThrow(() -> new NotFoundException(String.format("Accommodation with reservation ID %s not found.", reservationId)));
    }
}

