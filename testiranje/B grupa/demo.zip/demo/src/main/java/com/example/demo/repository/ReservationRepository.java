package com.example.demo.repository;

import com.example.demo.model.Reservation;

import java.util.Optional;

public interface ReservationRepository {

    Optional<Reservation> findById(long reservationId);

    void delete(Reservation reservation);
}
